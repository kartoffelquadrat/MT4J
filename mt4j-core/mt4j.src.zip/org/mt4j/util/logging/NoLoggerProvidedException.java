package org.mt4j.util.logging;

public class NoLoggerProvidedException extends RuntimeException {
	private static final long serialVersionUID = 1L;

}
